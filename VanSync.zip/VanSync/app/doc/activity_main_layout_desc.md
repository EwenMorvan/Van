# App Interface Design

Design a mobile app interface for controlling a van's systems. The app should include the following widgets:

## System Widget 🛠️
- A Bluetooth logo with the current connection state.
- A label displaying the system uptime.
- A status indicator for the communication state with the secondary PCB (connected or not).
- A clear error log (one line per error, clearly readable).
- A display for the system temperature.
- A button to start/stop the system fan.

## Light Widget 💡
### Interior Lights
- A button to turn lights on/off.
- A slider to adjust brightness.
- An RGB color picker to return an RGB color code.
- Advanced options:
  - A UI representing two LED strips in parallel (120 LEDs each). Users can touch a specific LED to turn it on or slide their finger over a section to activate it. They can also adjust the brightness and color of each LED/section selected.
  - A UI to configure animations for the LED strips.

### Exterior Lights
- A button to turn lights on/off.
- A slider to adjust brightness.
- An RGB color picker to return an RGB color code.

## Energy Widget ⚡
- A gauge (0-100%) to display the battery capacity, with additional technical details such as capacity (W/h) and voltage (V).
- A bi-directional watt gauge:
  - Red for consumed energy, green for charged energy, with 0 indicating no energy consumed/charged or equality.
  - Inside the gauge, display watt input for both MPPTs.

## Water Widget 💧
### Water Level Section
- A UI to visualize the water level in each tank:
  - Clean tank.
  - Two recycled tanks.
  - Two dirty tanks.

### Water Control Section
- A button to activate water to the sink.
- A button to activate water to the shower.
- Options to select the water input source (clean or recycled tank).
- Options to select the water output destination (dirty or recycled tank).

### Water Drainage and Rain Section
- A UI to drain water (dirty or recycled).
- A button to start/stop collecting rainwater.
- A button to reset all electrovalves and stop pumps.

## Habitacle Widget 🌡️
- A display for temperature.
- A display for humidity.
- A display for CO2 levels.
- A button to toggle the hood on/off.

## Heater Widget 🔥
- A button to turn the heater on/off.
- A gauge to display the current water temperature.
- A UI to set the desired water temperature and cabin temperature.
- A button to display the heater fan state and force it to start.

### Note
The app does not handle logic for button combinations. Each button click triggers a command to the ESP32, which decides if the command can be executed based on the system state. The ESP32 then sends back the updated system state as JSON, ensuring centralized logic and allowing multiple devices to control the van simultaneously.


{
  "type": "state",✅
  "timestamp": 1640995200000,✅
  "data": {
    "system": {
      "uptime": 86400000,✅
      "slave_pcb_connected": true,✅
      "system_error": false,✅
      "error_code": 0,✅
      "temperature": 45.2✅
    },
    "energy": {
      "battery_percentage": 85.5,
      "battery_capacity_wh": 2400.0,
      "battery_voltage": 12.8,
      "power_consumption": 150.5,
      "power_generation": 320.0
    },
    "mppt": {
      "solar_power_100_50": 180.5,
      "solar_power_70_15": 139.5
    },
    "water": {
      "clean_tank_level": 75.0,
      "recycled_tank1_level": 45.0,
      "recycled_tank2_level": 30.0,
      "dirty_tank1_level": 20.0,
      "dirty_tank2_level": 15.0
    },
    "sensors": {
      "cabin_temperature": 22.5,✅
      "onboard_temperature": 27.2,✅
      "humidity": 65.0,✅
      "co2_level": 450,✅
      "fuel_level": 57,✅
      "light_level": 89,✅
      "van_light_active": true,✅
    },
    "fans": {
      "hood_fan_active": false
    },
    "heater": {
      "heater_on": true,✅
      "water_temperature": 68.5,✅
      "target_water_temp": 75.0,✅
      "target_cabin_temp": 20.0,✅
      "radiator_fan_speed": 255,✅
      "pump_active": true,✅
    },
    "leds": {
      "interior": {
        "power_enabled": true,
        "brightness": 80,
        "color": -16776961
      },
      "exterior": {
        "power_enabled": false,
        "brightness": 50,
        "color": -65536
      }
    }
  }
}