package com.van.management.data;

public class VanState {
    
    public static class SystemData {
        public long uptime;
        public boolean system_error;
        public int error_code;
        public boolean slave_pcb_connected;
        public float temperature; // Will be mapped from onboard_temperature in postProcess
        
        public SystemData() {}
    }
    
    public static class SensorData {
        public float fuel_level;
        public float onboard_temperature;
        public float cabin_temperature;
        public float humidity;
        public int co2_level;
        public int light_level;
        public boolean van_light_active;
        public boolean door_open;
        
        public SensorData() {}
    }
    
    public static class HeaterData {
        public boolean heater_on;
        public float target_water_temp;
        public float target_cabin_temp;
        public float water_temperature;
        public boolean pump_active;
        public boolean fan_active; // Heater fan state
        public int radiator_fan_speed;
        
        public HeaterData() {}
        
        // Post-processing method to derive fan_active from radiator_fan_speed
        public void postProcess() {
            fan_active = radiator_fan_speed > 0;
        }
    }
    
    public static class MpptData {
        public float solar_power_100_50;
        public float battery_voltage_100_50;
        public float battery_current_100_50;
        public int temperature_100_50;
        public int state_100_50;
        public float solar_power_70_15;
        public float battery_voltage_70_15;
        public float battery_current_70_15;
        public int temperature_70_15;
        public int state_70_15;
        
        public MpptData() {}
    }
    
    public static class FanData {
        public int elec_box_speed;
        public int heater_fan_speed;
        public boolean hood_fan_active;
        
        public FanData() {}
    }
    
    public static class LedData {
        public RoofLed roof;
        public ExteriorLed exterior;
        public boolean error_mode_active;
        
        public static class RoofLed {
            public int current_mode;
            public int brightness;
            public boolean switch_pressed;
            public long last_switch_time;
            public boolean power_enabled; // Ajouté pour correspondre à l'interface
            public int color; // Ajouté pour correspondre à l'interface
            
            public RoofLed() {}
        }
        
        public static class ExteriorLed {
            public int current_mode;
            public int brightness;
            public int color;
            public boolean power_enabled;
            
            public ExteriorLed() {}
        }
        
        public LedData() {
            roof = new RoofLed();
            exterior = new ExteriorLed();
        }
    }
    
    public static class EnergyData {
        public float battery_percentage;
        public float battery_capacity_wh;
        public float battery_voltage;
        public float power_consumption;
        public float power_generation;
        
        public EnergyData() {}
    }
    
    public static class WaterData {
        public float clean_tank_level;
        public float recycled_tank1_level;
        public float recycled_tank2_level;
        public float dirty_tank1_level;
        public float dirty_tank2_level;
        public boolean sink_active;
        public boolean shower_active;
        public int water_source; // 0=clean, 1=recycled
        public int water_output; // 0=dirty, 1=recycled
        public boolean rain_collection_active;
        
        public WaterData() {}
    }
    
    public SystemData system;
    public SensorData sensors;
    public HeaterData heater;
    public MpptData mppt;
    public FanData fans;
    public LedData leds;
    public EnergyData energy;
    public WaterData water;
    
    public VanState() {
        system = new SystemData();
        sensors = new SensorData();
        heater = new HeaterData();
        mppt = new MpptData();
        fans = new FanData();
        leds = new LedData();
        energy = new EnergyData();
        water = new WaterData();
    }
    
    // Post-processing method to handle derived fields and missing data
    public void postProcess() {
        // Calculate derived fields
        if (heater != null) {
            heater.postProcess();
        }
        
        // Use onboard_temperature as system temperature (ESP32 sends it in sensors)
        if (system != null && sensors != null) {
            system.temperature = sensors.onboard_temperature;
        }
        
        // Add power_enabled and color to roof LED for UI compatibility
        if (leds != null && leds.roof != null) {
            // Derive power_enabled from brightness > 0
            leds.roof.power_enabled = leds.roof.brightness > 0;
            // Set default color if not provided
            if (leds.roof.color == 0) {
                leds.roof.color = -1; // Default white
            }
        }
        
        // Set default energy values (not provided by ESP32)
        if (energy != null) {
            // These would need to come from battery management system
            // For now, keep default values (0)
        }
        
        // Set default water values (not provided by ESP32)
        if (water != null) {
            // These would need to come from tank sensors
            // For now, keep default values (0)
        }
    }
}
