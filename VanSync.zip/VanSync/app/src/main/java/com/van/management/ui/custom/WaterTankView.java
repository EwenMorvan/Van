package com.van.management.ui.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.van.management.R;

public class WaterTankView extends View {
    private Paint tankPaint;
    private Paint waterPaint;
    private Paint textPaint;
    private RectF tankRect;
    private RectF waterRect;
    private int waterLevel = 0; // 0-100

    public WaterTankView(Context context) {
        super(context);
        init();
    }

    public WaterTankView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public WaterTankView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        tankPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        tankPaint.setColor(ContextCompat.getColor(getContext(), R.color.text_secondary_light));
        tankPaint.setStyle(Paint.Style.STROKE);
        tankPaint.setStrokeWidth(4f);

        waterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        waterPaint.setColor(ContextCompat.getColor(getContext(), R.color.primary));
        waterPaint.setStyle(Paint.Style.FILL);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(ContextCompat.getColor(getContext(), R.color.text_primary_light));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(16f);

        tankRect = new RectF();
        waterRect = new RectF();
    }

    public void setWaterLevel(int level) {
        this.waterLevel = Math.max(0, Math.min(100, level));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        int padding = 8;

        // Set tank rectangle
        tankRect.set(padding, padding, width - padding, height - padding);

        // Draw tank outline
        canvas.drawRoundRect(tankRect, 8f, 8f, tankPaint);

        // Draw water level
        if (waterLevel > 0) {
            float waterHeight = (tankRect.height() - 8) * (waterLevel / 100f);
            waterRect.set(tankRect.left + 4, tankRect.bottom - waterHeight - 4, 
                         tankRect.right - 4, tankRect.bottom - 4);
            canvas.drawRoundRect(waterRect, 4f, 4f, waterPaint);
        }

        // Draw percentage text
        String text = waterLevel + "%";
        float textY = tankRect.bottom + textPaint.getTextSize() + 8;
        canvas.drawText(text, width / 2f, textY, textPaint);
    }
}
