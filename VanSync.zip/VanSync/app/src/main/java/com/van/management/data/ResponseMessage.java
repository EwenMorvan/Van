package com.van.management.data;

public class ResponseMessage {
    public String type;
    public long timestamp;
    public String status;
    public String message;
    
    public ResponseMessage() {}
}
