package com.van.management.ble;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import com.google.gson.Gson;
import com.van.management.data.CommandMessage;
import com.van.management.data.ResponseMessage;
import com.van.management.data.StateMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class VanBleService extends Service {
    private static final String TAG = "VanBleService";
    
    // UUIDs du service van
    private static final String VAN_SERVICE_UUID = "0000AAA0-0000-1000-8000-00805F9B34FB";
    private static final String VAN_COMMAND_CHAR_UUID = "0000AAA1-0000-1000-8000-00805F9B34FB";
    private static final String VAN_STATE_CHAR_UUID = "0000AAA2-0000-1000-8000-00805F9B34FB";
    private static final String CLIENT_CONFIG_DESCRIPTOR_UUID = "00002902-0000-1000-8000-00805F9B34FB";
    
    // Actions d'Intent
    public static final String ACTION_GATT_CONNECTED = "com.van.management.ACTION_GATT_CONNECTED";
    public static final String ACTION_GATT_DISCONNECTED = "com.van.management.ACTION_GATT_DISCONNECTED";
    public static final String ACTION_GATT_SERVICES_DISCOVERED = "com.van.management.ACTION_GATT_SERVICES_DISCOVERED";
    public static final String ACTION_DATA_AVAILABLE = "com.van.management.ACTION_DATA_AVAILABLE";
    public static final String ACTION_COMMAND_RESPONSE = "com.van.management.ACTION_COMMAND_RESPONSE";
    public static final String EXTRA_DATA = "com.van.management.EXTRA_DATA";
    
    // Interface pour callback direct
    public interface VanBleCallback {
        void onDataReceived(String jsonData);
        void onConnectionStateChanged(boolean connected);
        void onServicesDiscovered();
    }
    
    private BluetoothManager bluetoothManager;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner bluetoothLeScanner;
    private BluetoothGatt bluetoothGatt;
    private BluetoothGattCharacteristic commandCharacteristic;
    private BluetoothGattCharacteristic stateCharacteristic;
    
    private Gson gson;
    private Handler mainHandler;
    private boolean isScanning = false;
    private boolean isConnected = false;
    
    // Buffer pour les données fragmentées
    private StringBuilder dataBuffer = new StringBuilder();
    
    // Callback direct pour contourner les problèmes de broadcast
    private VanBleCallback callback;
    
    // Variables pour la surveillance de connexion
    private long lastDataReceivedTime = 0;
    private static final long CONNECTION_TIMEOUT_MS = 1000; // 10 secondes sans données = déconnexion
    private static final long GATT_CHECK_INTERVAL_MS = 3000; // Vérifier la connexion GATT toutes les 3 secondes
    private Runnable connectionWatchdog;
    private Handler watchdogHandler;
    
    public class LocalBinder extends Binder {
        public VanBleService getService() {
            return VanBleService.this;
        }
    }
    
    public void setCallback(VanBleCallback callback) {
        this.callback = callback;
        Log.d(TAG, "Callback défini: " + (callback != null ? "oui" : "non"));
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();
        bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();
        gson = new Gson();
        mainHandler = new Handler(Looper.getMainLooper());
        watchdogHandler = new Handler(Looper.getMainLooper());
        
        Log.d(TAG, "Service BLE créé");
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return new LocalBinder();
    }
    
    // Callback pour le scan BLE
    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();
            String deviceName = null;
            
            try {
                deviceName = device.getName();
            } catch (SecurityException e) {
                Log.e(TAG, "Permission manquante pour obtenir le nom du dispositif: " + e.getMessage());
                return;
            }
            
            Log.d(TAG, "Dispositif trouvé: " + deviceName + " (" + device.getAddress() + ")");
            
            if (device != null && "VanManagement".equals(deviceName)) {
                Log.d(TAG, "Dispositif van trouvé: " + device.getAddress());
                stopScan();
                connectToDevice(device);
            }
        }
        
        @Override
        public void onScanFailed(int errorCode) {
            Log.e(TAG, "Échec du scan BLE - errorCode: " + errorCode);
            isScanning = false;
        }
    };
    
    // Callback GATT
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    Log.d(TAG, "Connecté au serveur GATT");
                    isConnected = true;
                    lastDataReceivedTime = System.currentTimeMillis();
                    startConnectionWatchdog();
                    broadcastUpdate(ACTION_GATT_CONNECTED);
                    
                    // Callback direct
                    if (callback != null) {
                        mainHandler.post(() -> callback.onConnectionStateChanged(true));
                    }
                    
                    // Demander un MTU plus grand avec un délai
                    mainHandler.postDelayed(() -> {
                        if (bluetoothGatt != null && isConnected) {
                            Log.d(TAG, "Demande de MTU...");
                            gatt.requestMtu(512);
                        }
                    }, 500);
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    Log.d(TAG, "Déconnecté du serveur GATT");
                    isConnected = false;
                    stopConnectionWatchdog();
                    broadcastUpdate(ACTION_GATT_DISCONNECTED);
                    
                    // Callback direct
                    if (callback != null) {
                        mainHandler.post(() -> callback.onConnectionStateChanged(false));
                    }
                }
            } else {
                Log.e(TAG, "Erreur de connexion GATT - status: " + status + ", newState: " + newState);
                isConnected = false;
                stopConnectionWatchdog();
                if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    broadcastUpdate(ACTION_GATT_DISCONNECTED);
                    
                    // Callback direct pour les erreurs aussi
                    if (callback != null) {
                        mainHandler.post(() -> callback.onConnectionStateChanged(false));
                    }
                }
                
                // Nettoyer la connexion en cas d'erreur
                if (bluetoothGatt != null) {
                    bluetoothGatt.close();
                    bluetoothGatt = null;
                }
            }
        }
        
        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG, "MTU changé à: " + mtu);
            } else {
                Log.w(TAG, "Échec changement MTU, status: " + status + ", utilisation MTU par défaut");
            }
            
            // Découvrir les services après changement de MTU (ou après échec)
            Log.d(TAG, "Découverte des services...");
            boolean success = gatt.discoverServices();
            if (!success) {
                Log.e(TAG, "Échec de la découverte des services");
            }
        }
        
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG, "Services découverts avec succès");
                
                BluetoothGattService vanService = gatt.getService(UUID.fromString(VAN_SERVICE_UUID));
                if (vanService != null) {
                    Log.d(TAG, "Service van trouvé");
                    commandCharacteristic = vanService.getCharacteristic(UUID.fromString(VAN_COMMAND_CHAR_UUID));
                    stateCharacteristic = vanService.getCharacteristic(UUID.fromString(VAN_STATE_CHAR_UUID));
                    
                    if (commandCharacteristic != null) {
                        Log.d(TAG, "Caractéristique de commande trouvée");
                    } else {
                        Log.e(TAG, "Caractéristique de commande non trouvée");
                    }
                    
                    // Activer les notifications pour les états
                    if (stateCharacteristic != null) {
                        Log.d(TAG, "Caractéristique d'état trouvée, activation des notifications");
                        boolean notifResult = gatt.setCharacteristicNotification(stateCharacteristic, true);
                        Log.d(TAG, "Notification activée: " + notifResult);
                        
                        BluetoothGattDescriptor descriptor = stateCharacteristic.getDescriptor(
                            UUID.fromString(CLIENT_CONFIG_DESCRIPTOR_UUID));
                        if (descriptor != null) {
                            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            boolean writeResult = gatt.writeDescriptor(descriptor);
                            Log.d(TAG, "Écriture descripteur: " + writeResult);
                        } else {
                            Log.e(TAG, "Descripteur de configuration client non trouvé");
                        }
                    } else {
                        Log.e(TAG, "Caractéristique d'état non trouvée");
                    }
                    
                    broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
                    
                    // Callback direct
                    if (callback != null) {
                        mainHandler.post(() -> callback.onServicesDiscovered());
                    }
                } else {
                    Log.e(TAG, "Service van non trouvé - UUID: " + VAN_SERVICE_UUID);
                    // Lister tous les services disponibles pour debug
                    for (BluetoothGattService service : gatt.getServices()) {
                        Log.d(TAG, "Service disponible: " + service.getUuid().toString());
                    }
                }
            } else {
                Log.e(TAG, "Échec de la découverte des services - status: " + status);
            }
        }
        
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            // Notification reçue (état du van)
            if (VAN_STATE_CHAR_UUID.equals(characteristic.getUuid().toString().toUpperCase())) {
                // Mettre à jour le timestamp de dernière réception de données
                lastDataReceivedTime = System.currentTimeMillis();
                
                String fragment = new String(characteristic.getValue());
                Log.d(TAG, "Fragment reçu: " + fragment);
                
                // Ajouter le fragment au buffer
                dataBuffer.append(fragment);
                
                // Vérifier si on a un JSON complet (commence par { et finit par })
                String bufferContent = dataBuffer.toString();
                if (bufferContent.startsWith("{") && bufferContent.endsWith("}")) {
                    // Compter les accolades pour s'assurer que le JSON est complet
                    int openBraces = 0;
                    int closeBraces = 0;
                    for (char c : bufferContent.toCharArray()) {
                        if (c == '{') openBraces++;
                        if (c == '}') closeBraces++;
                    }
                    
                    if (openBraces == closeBraces && openBraces > 0) {
                        Log.d(TAG, "JSON complet reçu: " + bufferContent);
                        
                        // Utiliser la méthode broadcastUpdate avec les données
                        broadcastUpdate(ACTION_DATA_AVAILABLE, bufferContent);
                        
                        // Callback direct pour contourner les problèmes de broadcast
                        if (callback != null) {
                            mainHandler.post(() -> callback.onDataReceived(bufferContent));
                        } else {
                            Log.w(TAG, "Aucun callback défini pour les données");
                        }
                        
                        // Vider le buffer
                        dataBuffer.setLength(0);
                    }
                } else if (bufferContent.length() > 20000) {
                    // Protection contre les buffers trop grands
                    Log.w(TAG, "Buffer trop grand, remise à zéro");
                    dataBuffer.setLength(0);
                }
            }
        }
        
        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG, "Commande envoyée avec succès");
            } else {
                Log.e(TAG, "Échec d'envoi de commande: " + status);
            }
        }
    };
    
    public void startScan() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            Log.e(TAG, "Bluetooth non disponible ou désactivé");
            return;
        }
        
        if (bluetoothLeScanner == null) {
            Log.e(TAG, "Scanner BLE non disponible");
            return;
        }
        
        if (isScanning) {
            Log.d(TAG, "Scan déjà en cours");
            return;
        }
        
        try {
            List<ScanFilter> filters = new ArrayList<>();
            ScanFilter filter = new ScanFilter.Builder()
                .setDeviceName("VanManagement")
                .build();
            filters.add(filter);
            
            ScanSettings settings = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build();
            
            bluetoothLeScanner.startScan(filters, settings, scanCallback);
            isScanning = true;
            Log.d(TAG, "Scan BLE démarré");
            
            // Arrêter le scan après 10 secondes
            mainHandler.postDelayed(this::stopScan, 10000);
        } catch (SecurityException e) {
            Log.e(TAG, "Permission manquante pour le scan BLE: " + e.getMessage());
            isScanning = false;
        } catch (Exception e) {
            Log.e(TAG, "Erreur lors du démarrage du scan BLE: " + e.getMessage());
            isScanning = false;
        }
    }
    
    public void stopScan() {
        if (bluetoothLeScanner != null && isScanning) {
            try {
                bluetoothLeScanner.stopScan(scanCallback);
                Log.d(TAG, "Scan BLE arrêté");
            } catch (SecurityException e) {
                Log.e(TAG, "Permission manquante pour arrêter le scan BLE: " + e.getMessage());
            } catch (Exception e) {
                Log.e(TAG, "Erreur lors de l'arrêt du scan BLE: " + e.getMessage());
            } finally {
                isScanning = false;
            }
        }
    }
    
    private void connectToDevice(BluetoothDevice device) {
        if (bluetoothGatt != null) {
            Log.d(TAG, "Fermeture de la connexion GATT existante");
            bluetoothGatt.close();
            bluetoothGatt = null;
        }
        
        Log.d(TAG, "Tentative de connexion au dispositif: " + device.getAddress());
        
        // Ajouter un délai avant la connexion pour éviter les problèmes de timing
        mainHandler.postDelayed(() -> {
            try {
                bluetoothGatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
                if (bluetoothGatt == null) {
                    Log.e(TAG, "Échec de création de la connexion GATT");
                    broadcastUpdate(ACTION_GATT_DISCONNECTED);
                }
            } catch (SecurityException e) {
                Log.e(TAG, "Permission manquante pour la connexion BLE: " + e.getMessage());
                broadcastUpdate(ACTION_GATT_DISCONNECTED);
            }
        }, 100);
    }
    
    public void disconnect() {
        Log.d(TAG, "Déconnexion demandée");
        isConnected = false;
        stopConnectionWatchdog();
        
        if (bluetoothGatt != null) {
            try {
                bluetoothGatt.disconnect();
                // Délai avant de fermer pour permettre une déconnexion propre
                mainHandler.postDelayed(() -> {
                    if (bluetoothGatt != null) {
                        bluetoothGatt.close();
                        bluetoothGatt = null;
                        Log.d(TAG, "Connexion GATT fermée");
                    }
                }, 500);
            } catch (Exception e) {
                Log.e(TAG, "Erreur lors de la déconnexion: " + e.getMessage());
                if (bluetoothGatt != null) {
                    bluetoothGatt.close();
                    bluetoothGatt = null;
                }
            }
        }
        
        // Nettoyer les caractéristiques
        commandCharacteristic = null;
        stateCharacteristic = null;
    }
    
    public boolean sendCommand(String cmd, int target, int value) {
        if (commandCharacteristic == null || !isConnected) {
            Log.e(TAG, "Pas de connexion ou caractéristique manquante");
            return false;
        }
        
        CommandMessage command = new CommandMessage(cmd, target, value);
        String json = gson.toJson(command);
        
        commandCharacteristic.setValue(json.getBytes());
        boolean result = bluetoothGatt.writeCharacteristic(commandCharacteristic);
        
        Log.d(TAG, "Envoi commande: " + json + " -> " + result);
        return result;
    }
    
    public boolean isConnected() {
        return isConnected;
    }
    
    public boolean isScanning() {
        return isScanning;
    }
    
    /**
     * Teste manuellement la connexion pour déclencher une détection de déconnexion si nécessaire
     */
    public void testConnection() {
        Log.d(TAG, "Test manuel de connexion demandé");
        if (isConnected && bluetoothGatt != null) {
            BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothDevice device = bluetoothGatt.getDevice();
            int connectionState = bluetoothManager.getConnectionState(device, BluetoothProfile.GATT);
            
            Log.d(TAG, "Test connexion - État GATT: " + connectionState);
            Log.d(TAG, "Test connexion - isConnected: " + isConnected);
            Log.d(TAG, "Test connexion - Dernières données: " + (System.currentTimeMillis() - lastDataReceivedTime) + "ms");
            
            if (connectionState != BluetoothProfile.STATE_CONNECTED) {
                Log.w(TAG, "Test connexion - Déconnexion détectée!");
                forceDisconnection();
            }
        } else {
            Log.d(TAG, "Test connexion - Pas de connexion active");
        }
    }
    
    private void broadcastUpdate(String action) {
        Intent intent = new Intent(action);
        Log.d(TAG, "Envoi broadcast: " + action);
        sendBroadcast(intent);
    }
    
    private void broadcastUpdate(String action, String data) {
        Intent intent = new Intent(action);
        intent.putExtra(EXTRA_DATA, data);
        Log.d(TAG, "Envoi broadcast: " + action + " avec données de longueur: " + (data != null ? data.length() : "null"));
        sendBroadcast(intent);
    }
    
    /**
     * Démarre la surveillance de la connexion pour détecter les déconnexions silencieuses
     */
    private void startConnectionWatchdog() {
        Log.d(TAG, "=== DÉMARRAGE WATCHDOG DE CONNEXION ===");
        stopConnectionWatchdog(); // Arrêter le précédent s'il existe
        
        connectionWatchdog = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "Watchdog exécuté - isConnected: " + isConnected + ", bluetoothGatt: " + (bluetoothGatt != null));
                
                if (isConnected) {
                    long timeSinceLastData = System.currentTimeMillis() - lastDataReceivedTime;
                    Log.d(TAG, "Watchdog: dernières données reçues il y a " + timeSinceLastData + "ms (timeout: " + CONNECTION_TIMEOUT_MS + "ms)");
                    
                    boolean shouldDisconnect = false;
                    String reason = "";
                    
                    // Vérification principale : données reçues récemment ?
                    if (timeSinceLastData > CONNECTION_TIMEOUT_MS) {
                        shouldDisconnect = true;
                        reason = "Timeout de données (" + timeSinceLastData + "ms)";
                    }
                    
                    // Vérification secondaire : état GATT
                    if (bluetoothGatt != null) {
                        try {
                            BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
                            BluetoothDevice device = bluetoothGatt.getDevice();
                            int connectionState = bluetoothManager.getConnectionState(device, BluetoothProfile.GATT);
                            
                            Log.d(TAG, "État GATT: " + connectionState + " (STATE_CONNECTED=" + BluetoothProfile.STATE_CONNECTED + ")");
                            
                            if (connectionState != BluetoothProfile.STATE_CONNECTED) {
                                shouldDisconnect = true;
                                reason = "État GATT déconnecté (" + connectionState + ")";
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Erreur lors de la vérification GATT: " + e.getMessage());
                            shouldDisconnect = true;
                            reason = "Erreur GATT: " + e.getMessage();
                        }
                    }
                    
                    if (shouldDisconnect) {
                        Log.w(TAG, "=== DÉCONNEXION FORCÉE DÉTECTÉE ===");
                        Log.w(TAG, "Raison: " + reason);
                        forceDisconnection();
                    } else {
                        Log.d(TAG, "Connexion OK, reprogrammation du watchdog dans 3s");
                        // Programmer la prochaine vérification
                        watchdogHandler.postDelayed(this, 3000);
                    }
                } else {
                    Log.d(TAG, "Watchdog arrêté car pas connecté");
                }
            }
        };
        
        // Première vérification dans 3 secondes
        Log.d(TAG, "Programmation première vérification watchdog dans 3s");
        watchdogHandler.postDelayed(connectionWatchdog, 3000);
    }
    
    /**
     * Arrête la surveillance de la connexion
     */
    private void stopConnectionWatchdog() {
        if (connectionWatchdog != null) {
            watchdogHandler.removeCallbacks(connectionWatchdog);
            connectionWatchdog = null;
            Log.d(TAG, "Watchdog de connexion arrêté");
        }
    }
    
    /**
     * Force une déconnexion en cas de timeout détecté
     */
    private void forceDisconnection() {
        Log.w(TAG, "Déconnexion forcée suite à un timeout");
        
        // Marquer comme déconnecté
        isConnected = false;
        
        // Arrêter le watchdog
        stopConnectionWatchdog();
        
        // Fermer la connexion GATT
        if (bluetoothGatt != null) {
            bluetoothGatt.disconnect();
            bluetoothGatt.close();
            bluetoothGatt = null;
        }
        
        // Nettoyer le buffer
        dataBuffer.setLength(0);
        
        // Notifier la déconnexion
        broadcastUpdate(ACTION_GATT_DISCONNECTED);
        
        // Callback direct
        if (callback != null) {
            mainHandler.post(() -> callback.onConnectionStateChanged(false));
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopConnectionWatchdog();
        stopScan();
        disconnect();
        Log.d(TAG, "Service BLE détruit");
    }
}
