package com.van.management.ui.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.van.management.R;

public class BatteryGaugeView extends View {
    private Paint backgroundPaint;
    private Paint batteryPaint;
    private Paint textPaint;
    private RectF batteryRect;
    private int batteryLevel = 0; // 0-100

    public BatteryGaugeView(Context context) {
        super(context);
        init();
    }

    public BatteryGaugeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BatteryGaugeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        backgroundPaint.setColor(ContextCompat.getColor(getContext(), R.color.text_secondary_light));
        backgroundPaint.setStyle(Paint.Style.STROKE);
        backgroundPaint.setStrokeWidth(8f);

        batteryPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        batteryPaint.setStyle(Paint.Style.FILL);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(ContextCompat.getColor(getContext(), R.color.text_primary_light));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(32f);

        batteryRect = new RectF();
    }

    public void setBatteryLevel(int level) {
        this.batteryLevel = Math.max(0, Math.min(100, level));
        updateBatteryColor();
        invalidate();
    }

    private void updateBatteryColor() {
        if (batteryLevel > 50) {
            batteryPaint.setColor(ContextCompat.getColor(getContext(), R.color.connected));
        } else if (batteryLevel > 20) {
            batteryPaint.setColor(ContextCompat.getColor(getContext(), R.color.warning));
        } else {
            batteryPaint.setColor(ContextCompat.getColor(getContext(), R.color.error));
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        int size = Math.min(width, height);
        int centerX = width / 2;
        int centerY = height / 2;
        int radius = size / 2 - 20;

        // Draw background circle
        canvas.drawCircle(centerX, centerY, radius, backgroundPaint);

        // Draw battery level arc
        batteryRect.set(centerX - radius, centerY - radius, centerX + radius, centerY + radius);
        float sweepAngle = (batteryLevel / 100f) * 360f;
        canvas.drawArc(batteryRect, -90, sweepAngle, true, batteryPaint);

        // Draw percentage text
        String text = batteryLevel + "%";
        float textY = centerY + textPaint.getTextSize() / 3;
        canvas.drawText(text, centerX, textY, textPaint);
    }
}
