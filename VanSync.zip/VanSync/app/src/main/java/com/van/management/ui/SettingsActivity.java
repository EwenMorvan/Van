package com.van.management.ui;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.van.management.R;
import com.van.management.utils.PreferencesManager;

public class SettingsActivity extends AppCompatActivity {
    
    private PreferencesManager preferencesManager;
    
    private CheckBox autoConnectCheckbox;
    private CheckBox keepScreenOnCheckbox;
    private CheckBox darkThemeCheckbox;
    private SeekBar intervalSeekBar;
    private TextView intervalText;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        
        preferencesManager = new PreferencesManager(this);
        
        initializeUI();
        loadSettings();
        setupListeners();
        
        // Activer le bouton retour
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }
    
    private void initializeUI() {
        autoConnectCheckbox = findViewById(R.id.auto_connect_checkbox);
        keepScreenOnCheckbox = findViewById(R.id.keep_screen_on_checkbox);
        darkThemeCheckbox = findViewById(R.id.dark_theme_checkbox);
        intervalSeekBar = findViewById(R.id.interval_seekbar);
        intervalText = findViewById(R.id.interval_text);
    }
    
    private void loadSettings() {
        autoConnectCheckbox.setChecked(preferencesManager.getAutoConnect());
        keepScreenOnCheckbox.setChecked(preferencesManager.getKeepScreenOn());
        darkThemeCheckbox.setChecked(preferencesManager.getDarkTheme());
        
        int interval = preferencesManager.getNotificationInterval();
        intervalSeekBar.setProgress(intervalToProgress(interval));
        updateIntervalText(interval);
    }
    
    private void setupListeners() {
        autoConnectCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> 
            preferencesManager.setAutoConnect(isChecked));
            
        keepScreenOnCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> 
            preferencesManager.setKeepScreenOn(isChecked));
            
        darkThemeCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            preferencesManager.setDarkTheme(isChecked);
            // Redémarrer l'activité pour appliquer le thème
            recreate();
        });
        
        intervalSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    int interval = progressToInterval(progress);
                    updateIntervalText(interval);
                    preferencesManager.setNotificationInterval(interval);
                }
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }
    
    private int intervalToProgress(int interval) {
        // Convertir intervalle (100-5000ms) en progress (0-100)
        if (interval <= 100) return 0;
        if (interval >= 5000) return 100;
        return (interval - 100) * 100 / 4900;
    }
    
    private int progressToInterval(int progress) {
        // Convertir progress (0-100) en intervalle (100-5000ms)
        return 100 + (progress * 4900 / 100);
    }
    
    private void updateIntervalText(int interval) {
        if (interval < 1000) {
            intervalText.setText(interval + " ms");
        } else {
            intervalText.setText(String.format("%.1f s", interval / 1000.0));
        }
    }
    
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
