package com.van.management.ui;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.van.management.R;
import com.van.management.ble.VanBleService;
import com.van.management.data.StateMessage;
import com.van.management.data.VanState;
import com.van.management.ui.custom.BatteryGaugeView;
import com.van.management.ui.custom.LedStripView;
import com.van.management.ui.custom.PowerGaugeView;
import com.van.management.ui.custom.WaterTankView;
import com.van.management.ui.custom.WaterTempGaugeView;
import com.van.management.utils.ErrorCodes;
import com.van.management.utils.PreferencesManager;

public class MainActivity extends AppCompatActivity implements VanBleService.VanBleCallback {
    private static final String TAG = "MainActivity";
    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_PERMISSIONS = 2;
    
    // Service BLE
    private VanBleService bleService;
    private boolean serviceConnected = false;
    
    // System Widget UI Elements
    private ImageView bluetoothIcon;
    private TextView bluetoothStatus;
    private Button connectButton;
    private TextView uptimeText;
    private TextView slavePcbStatus;
    private TextView errorLog;
    private TextView systemTemperature;
    private Button systemFanButton;
    
    // Light Widget UI Elements
    private Switch interiorLightsSwitch;
    private SeekBar interiorBrightnessSeekBar;
    private TextView interiorModeText;
    private Button interiorModeUpButton;
    private Button interiorModeDownButton;
    private View interiorColorPreview;
    private Button interiorColorPickerButton;
    private LedStripView ledStripView;
    private Button ledAnimationsButton;
    private Switch exteriorLightsSwitch;
    private SeekBar exteriorBrightnessSeekBar;
    private TextView exteriorModeText;
    private Button exteriorModeUpButton;
    private Button exteriorModeDownButton;
    private View exteriorColorPreview;
    private Button exteriorColorPickerButton;
    
    // Energy Widget UI Elements
    private BatteryGaugeView batteryGauge;
    private TextView batteryPercentage;
    private TextView batteryCapacity;
    private TextView batteryVoltage;
    private PowerGaugeView powerGauge;
    private TextView powerConsumption;
    private TextView powerGeneration;
    private TextView mppt1Power;
    private TextView mppt2Power;
    
    // Water Widget UI Elements
    private WaterTankView cleanTank;
    private WaterTankView recycledTank1;
    private WaterTankView recycledTank2;
    private WaterTankView dirtyTank1;
    private WaterTankView dirtyTank2;
    private Button waterSinkButton;
    private Button waterShowerButton;
    private RadioGroup waterSourceGroup;
    private RadioGroup waterOutputGroup;
    private Button drainDirtyButton;
    private Button drainRecycledButton;
    private Button rainCollectionButton;
    private Button resetWaterButton;
    
    // Habitacle Widget UI Elements
    private TextView cabinTemperature;
    private TextView cabinHumidity;
    private TextView cabinCo2;
    private Switch hoodSwitch;
    
    // Heater Widget UI Elements
    private Switch heaterSwitch;
    private TextView currentWaterTempText;
    private WaterTempGaugeView waterTempGauge;
    private TextView waterTempDisplay;
    private SeekBar waterTempSeekBar;
    private TextView waterTempText;
    private SeekBar cabinTempSeekBar;
    private TextView cabinTempSettingText;
    private TextView heaterFanStatus;
    private Button heaterFanForceButton;
    
    private Gson gson;
    private PreferencesManager preferencesManager;
    private VanState lastVanState;
    
    // Flag pour éviter les boucles lors des mises à jour UI
    private boolean isUpdatingUI = false;
    
    // Variables pour la reconnexion automatique
    private boolean autoReconnectEnabled = true;
    private int reconnectAttempts = 0;
    private static final int MAX_RECONNECT_ATTEMPTS = 5;
    private static final int RECONNECT_DELAY_MS = 3000; // 3 secondes
    private Runnable reconnectRunnable;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Log.d(TAG, "MainActivity onCreate() démarré");
        
        gson = new Gson();
        preferencesManager = new PreferencesManager(this);
        
        Log.d(TAG, "Initialisation UI...");
        initializeUI();
        
        Log.d(TAG, "Vérification des permissions...");
        checkPermissions();
        
        // Garder l'écran allumé si configuré
        if (preferencesManager.getKeepScreenOn()) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        
        Log.d(TAG, "MainActivity onCreate() terminé");
    }
    
    private void initializeUI() {
        // System Widget
        bluetoothIcon = findViewById(R.id.bluetooth_icon);
        bluetoothStatus = findViewById(R.id.bluetooth_status);
        connectButton = findViewById(R.id.connect_button);
        uptimeText = findViewById(R.id.uptime_text);
        slavePcbStatus = findViewById(R.id.slave_pcb_status);
        errorLog = findViewById(R.id.error_log);
        systemTemperature = findViewById(R.id.system_temperature);
        systemFanButton = findViewById(R.id.system_fan_button);
        
        // Light Widget
        interiorLightsSwitch = findViewById(R.id.interior_lights_switch);
        interiorBrightnessSeekBar = findViewById(R.id.interior_brightness_seekbar);
        interiorModeText = findViewById(R.id.interior_mode_text);
        interiorModeUpButton = findViewById(R.id.interior_mode_up_button);
        interiorModeDownButton = findViewById(R.id.interior_mode_down_button);
        interiorColorPreview = findViewById(R.id.interior_color_preview);
        interiorColorPickerButton = findViewById(R.id.interior_color_picker_button);
        ledStripView = findViewById(R.id.led_strip_view);
        ledAnimationsButton = findViewById(R.id.led_animations_button);
        exteriorLightsSwitch = findViewById(R.id.exterior_lights_switch);
        exteriorBrightnessSeekBar = findViewById(R.id.exterior_brightness_seekbar);
        exteriorModeText = findViewById(R.id.exterior_mode_text);
        exteriorModeUpButton = findViewById(R.id.exterior_mode_up_button);
        exteriorModeDownButton = findViewById(R.id.exterior_mode_down_button);
        exteriorColorPreview = findViewById(R.id.exterior_color_preview);
        exteriorColorPickerButton = findViewById(R.id.exterior_color_picker_button);
        
        // Energy Widget
        batteryGauge = findViewById(R.id.battery_gauge);
        batteryPercentage = findViewById(R.id.battery_percentage);
        batteryCapacity = findViewById(R.id.battery_capacity);
        batteryVoltage = findViewById(R.id.battery_voltage);
        powerGauge = findViewById(R.id.power_gauge);
        powerConsumption = findViewById(R.id.power_consumption);
        powerGeneration = findViewById(R.id.power_generation);
        mppt1Power = findViewById(R.id.mppt1_power);
        mppt2Power = findViewById(R.id.mppt2_power);
        
        // Water Widget
        cleanTank = findViewById(R.id.clean_tank);
        recycledTank1 = findViewById(R.id.recycled_tank_1);
        recycledTank2 = findViewById(R.id.recycled_tank_2);
        dirtyTank1 = findViewById(R.id.dirty_tank_1);
        dirtyTank2 = findViewById(R.id.dirty_tank_2);
        waterSinkButton = findViewById(R.id.water_sink_button);
        waterShowerButton = findViewById(R.id.water_shower_button);
        waterSourceGroup = findViewById(R.id.water_source_group);
        waterOutputGroup = findViewById(R.id.water_output_group);
        drainDirtyButton = findViewById(R.id.drain_dirty_button);
        drainRecycledButton = findViewById(R.id.drain_recycled_button);
        rainCollectionButton = findViewById(R.id.rain_collection_button);
        resetWaterButton = findViewById(R.id.reset_water_button);
        
        // Habitacle Widget
        cabinTemperature = findViewById(R.id.cabin_temperature);
        cabinHumidity = findViewById(R.id.cabin_humidity);
        cabinCo2 = findViewById(R.id.cabin_co2);
        hoodSwitch = findViewById(R.id.hood_switch);
        
        // Heater Widget
        heaterSwitch = findViewById(R.id.heater_switch);
        currentWaterTempText = findViewById(R.id.current_water_temp_text);
        waterTempGauge = findViewById(R.id.water_temp_gauge);
        waterTempDisplay = findViewById(R.id.water_temp_display);
        waterTempSeekBar = findViewById(R.id.water_temp_seekbar);
        waterTempText = findViewById(R.id.water_temp_text);
        cabinTempSeekBar = findViewById(R.id.cabin_temp_seekbar);
        cabinTempSettingText = findViewById(R.id.cabin_temp_setting_text);
        heaterFanStatus = findViewById(R.id.heater_fan_status);
        heaterFanForceButton = findViewById(R.id.heater_fan_force_button);
        
        // Masquer complètement le bouton de connexion pour l'auto-connexion
        connectButton.setVisibility(View.GONE);
        Log.d(TAG, "Bouton de connexion masqué pour mode auto-connexion");
        
        setupEventListeners();
    }
    
    private void setupEventListeners() {
        // System Widget
        connectButton.setOnClickListener(v -> {
            if (serviceConnected && bleService != null) {
                if (bleService.isConnected()) {
                    Log.d(TAG, "Test de connexion demandé");
                    bleService.testConnection();
                    Toast.makeText(this, "Test de connexion effectué", Toast.LENGTH_SHORT).show();
                } else if (bleService.isScanning()) {
                    bleService.stopScan();
                } else {
                    bleService.startScan();
                }
            }
        });
        
        systemFanButton.setOnClickListener(v -> sendCommand("toggle_system_fan", 0, 0));
        
        // Light Widget
        interiorLightsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isUpdatingUI) {
                sendCommand("set_led_state", 0, isChecked ? 1 : 0); // 0 = interior
            }
        });
            
        interiorBrightnessSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (!isUpdatingUI) {
                    sendCommand("set_led_brightness", 0, seekBar.getProgress()); // 0 = interior
                }
            }
        });
        
        interiorColorPickerButton.setOnClickListener(v -> showColorPicker(true));
        
        // Interior LED mode controls
        interiorModeUpButton.setOnClickListener(v -> {
            if (lastVanState != null && lastVanState.leds != null && lastVanState.leds.roof != null) {
                int currentMode = lastVanState.leds.roof.current_mode;
                sendCommand("set_led_mode", 0, currentMode + 1); // 0 = interior
            }
        });
        
        interiorModeDownButton.setOnClickListener(v -> {
            if (lastVanState != null && lastVanState.leds != null && lastVanState.leds.roof != null) {
                int currentMode = lastVanState.leds.roof.current_mode;
                if (currentMode > 1) { // Empêcher de descendre en dessous du mode 1
                    sendCommand("set_led_mode", 0, currentMode - 1); // 0 = interior
                }
            }
        });
        
        exteriorLightsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isUpdatingUI) {
                sendCommand("set_led_state", 1, isChecked ? 1 : 0); // 1 = exterior
            }
        });
            
        exteriorBrightnessSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {}
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (!isUpdatingUI) {
                    sendCommand("set_led_brightness", 1, seekBar.getProgress()); // 1 = exterior
                }
            }
        });
        
        exteriorColorPickerButton.setOnClickListener(v -> showColorPicker(false));
        
        // Exterior LED mode controls
        exteriorModeUpButton.setOnClickListener(v -> {
            if (lastVanState != null && lastVanState.leds != null && lastVanState.leds.exterior != null) {
                int currentMode = lastVanState.leds.exterior.current_mode;
                sendCommand("set_led_mode", 1, currentMode + 1); // 1 = exterior
            }
        });
        
        exteriorModeDownButton.setOnClickListener(v -> {
            if (lastVanState != null && lastVanState.leds != null && lastVanState.leds.exterior != null) {
                int currentMode = lastVanState.leds.exterior.current_mode;
                if (currentMode > 1) { // Empêcher de descendre en dessous du mode 1
                    sendCommand("set_led_mode", 1, currentMode - 1); // 1 = exterior
                }
            }
        });
        
        ledAnimationsButton.setOnClickListener(v -> showAnimationDialog());
        
        // LED Strip View
        ledStripView.setOnLedSelectionListener(new LedStripView.OnLedSelectionListener() {
            @Override
            public void onLedSelected(int ledIndex, int color, int brightness) {
                sendCommand("set_led_individual", ledIndex, color);
            }
            
            @Override
            public void onLedRangeSelected(int startIndex, int endIndex, int color, int brightness) {
                sendCommand("set_led_range", startIndex, endIndex);
            }
        });
        
        // Water Widget
        waterSinkButton.setOnClickListener(v -> sendCommand("activate_water_sink", 0, 0));
        waterShowerButton.setOnClickListener(v -> sendCommand("activate_water_shower", 0, 0));
        
        waterSourceGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (!isUpdatingUI) {
                int source = checkedId == R.id.source_clean ? 0 : 1;
                sendCommand("set_water_source", 0, source);
            }
        });
        
        waterOutputGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (!isUpdatingUI) {
                int output = checkedId == R.id.output_dirty ? 0 : 1;
                sendCommand("set_water_output", 0, output);
            }
        });
        
        drainDirtyButton.setOnClickListener(v -> sendCommand("drain_water", 0, 0));
        drainRecycledButton.setOnClickListener(v -> sendCommand("drain_water", 1, 0));
        rainCollectionButton.setOnClickListener(v -> sendCommand("toggle_rain_collection", 0, 0));
        resetWaterButton.setOnClickListener(v -> sendCommand("reset_water_system", 0, 0));
        
        // Habitacle Widget
        hoodSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isUpdatingUI) {
                sendCommand("set_hood", 0, isChecked ? 1 : 0);
            }
        });
        
        // Heater Widget
        heaterSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isUpdatingUI) {
                sendCommand("set_heater_state", 0, isChecked ? 1 : 0);
            }
        });
            
        waterTempSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    int temp = progress + 40; // 40-120°C
                    waterTempText.setText(temp + "°C");
                }
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (!isUpdatingUI) {
                    int temp = seekBar.getProgress() + 40;
                    sendCommand("set_water_temp_target", 0, temp);
                }
            }
        });
        
        cabinTempSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    int temp = progress + 15; // 15-45°C
                    cabinTempSettingText.setText(temp + "°C");
                }
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (!isUpdatingUI) {
                    int temp = seekBar.getProgress() + 15;
                    sendCommand("set_cabin_temp_target", 0, temp);
                }
            }
        });
        
        heaterFanForceButton.setOnClickListener(v -> sendCommand("force_heater_fan", 0, 0));
    }
    
    private void showColorPicker(boolean isInterior) {
        // TODO: Implement color picker dialog
        Toast.makeText(this, "Sélecteur de couleur - À implémenter", Toast.LENGTH_SHORT).show();
    }
    
    private void showAnimationDialog() {
        // TODO: Implement animation selection dialog
        Toast.makeText(this, "Animations LED - À implémenter", Toast.LENGTH_SHORT).show();
    }
    
    
    private void checkPermissions() {
        String[] permissions = {
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.ACCESS_FINE_LOCATION
        };
        
        boolean allGranted = true;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }
        
        if (!allGranted) {
            ActivityCompat.requestPermissions(this, permissions, REQUEST_PERMISSIONS);
        } else {
            initializeBluetooth();
        }
    }
    
    private void initializeBluetooth() {
        BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter bluetoothAdapter = bluetoothManager.getAdapter();
        
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth non supporté", Toast.LENGTH_LONG).show();
            return;
        }
        
        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            startBleService();
        }
    }
    
    private void startBleService() {
        Log.d(TAG, "Démarrage du service BLE...");
        Intent intent = new Intent(this, VanBleService.class);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
        
        // Enregistrer les receivers pour les événements BLE
        IntentFilter filter = new IntentFilter();
        filter.addAction(VanBleService.ACTION_GATT_CONNECTED);
        filter.addAction(VanBleService.ACTION_GATT_DISCONNECTED);
        filter.addAction(VanBleService.ACTION_GATT_SERVICES_DISCOVERED);
        filter.addAction(VanBleService.ACTION_DATA_AVAILABLE);
        
        // Pour Android 14+ (API 34+), spécifier RECEIVER_NOT_EXPORTED car c'est un receiver interne
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            registerReceiver(bleReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            Log.d(TAG, "BroadcastReceiver enregistré avec RECEIVER_NOT_EXPORTED");
        } else {
            registerReceiver(bleReceiver, filter);
            Log.d(TAG, "BroadcastReceiver enregistré sans flags");
        }
        
        // Log toutes les actions enregistrées
        Log.d(TAG, "Actions enregistrées dans le filter:");
        for (int i = 0; i < filter.countActions(); i++) {
            Log.d(TAG, "  - " + filter.getAction(i));
        }
        
        if (preferencesManager.getAutoConnect()) {
            // Auto-connexion après un délai
            connectButton.postDelayed(() -> {
                if (serviceConnected && !bleService.isConnected()) {
                    bleService.startScan();
                }
            }, 1000);
        } else {
            // Permettre à l'utilisateur de contrôler la connexion manuellement
            updateConnectionStatus();
        }
    }
    
    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            VanBleService.LocalBinder binder = (VanBleService.LocalBinder) service;
            bleService = binder.getService();
            serviceConnected = true;
            
            // Définir le callback direct
            bleService.setCallback(MainActivity.this);
            
            updateConnectionStatus();
            Log.d(TAG, "Service BLE connecté et callback configuré");
        }
        
        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceConnected = false;
            bleService = null;
            Log.d(TAG, "Service BLE déconnecté");
        }
    };
    
    private final BroadcastReceiver bleReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) {
                Log.w(TAG, "BroadcastReceiver: Intent null reçu");
                return;
            }
            
            String action = intent.getAction();
            Log.d(TAG, "BroadcastReceiver.onReceive() appelé avec action: " + action);
            Log.d(TAG, "Intent extras: " + (intent.getExtras() != null ? intent.getExtras().toString() : "null"));
            
            if (action == null) {
                Log.w(TAG, "Action null dans l'intent");
                return;
            }
            
            switch (action) {
                case VanBleService.ACTION_GATT_CONNECTED:
                    Log.d(TAG, "Traitement ACTION_GATT_CONNECTED");
                    updateConnectionStatus();
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Connecté au van", Toast.LENGTH_SHORT).show());
                    break;
                    
                case VanBleService.ACTION_GATT_DISCONNECTED:
                    Log.d(TAG, "Traitement ACTION_GATT_DISCONNECTED");
                    updateConnectionStatus();
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Déconnecté du van", Toast.LENGTH_SHORT).show());
                    break;
                    
                case VanBleService.ACTION_GATT_SERVICES_DISCOVERED:
                    Log.d(TAG, "Traitement ACTION_GATT_SERVICES_DISCOVERED");
                    runOnUiThread(() -> bluetoothStatus.setText("Services découverts - Prêt"));
                    break;
                    
                case VanBleService.ACTION_DATA_AVAILABLE:
                    Log.d(TAG, "=== TRAITEMENT ACTION_DATA_AVAILABLE ===");
                    String data = intent.getStringExtra(VanBleService.EXTRA_DATA);
                    handleVanStateUpdate(data);
                    break;
                    
                default:
                    Log.w(TAG, "Action inconnue reçue: " + action);
                    break;
            }
        }
    };
    
    private void handleVanStateUpdate(String jsonData) {
        // Log.d(TAG, "Contenu JSON reçu: " + jsonData);
        try {
            StateMessage stateMessage = gson.fromJson(jsonData, StateMessage.class);
            lastVanState = stateMessage.data;
            
            // Post-process the data to handle derived fields and mappings
            if (lastVanState != null) {
                lastVanState.postProcess();
            }
            
            Log.d(TAG, "Parsing JSON réussi, mise à jour UI");
            updateUI(lastVanState);
        } catch (Exception e) {
            Log.e(TAG, "Erreur parsing JSON: " + e.getMessage());
            if (jsonData != null) {
                Log.e(TAG, "JSON en erreur: " + jsonData.substring(0, Math.min(200, jsonData.length())));
            }
        }
    }
    
    private void updateUI(VanState state) {
        runOnUiThread(() -> {
            // Activer le flag pour éviter les commandes pendant la mise à jour UI
            isUpdatingUI = true;
            
            try {
                Log.d(TAG, "Update UI called!");
                Log.d(TAG, "Contenu complet de VanState: " + gson.toJson(state));
                Log.d(TAG, "Uptime " + state.system.uptime);
                // System Widget
                uptimeText.setText("Temps de fonctionnement: " + formatUptime(state.system.uptime));
                slavePcbStatus.setText("PCB secondaire: " + (state.system.slave_pcb_connected ? "Connecté" : "Déconnecté"));
                systemTemperature.setText(String.format("Température système: %.1f°C", state.system.temperature));
                
                // Error Log
                if (state.system.system_error) {
                    errorLog.setText("Erreurs: " + ErrorCodes.getErrorString(state.system.error_code));
                } else {
                    errorLog.setText("Aucune erreur");
                }
                
                // Energy Widget
                batteryGauge.setBatteryLevel((int) state.energy.battery_percentage);
                batteryPercentage.setText(String.format("Batterie: %.1f%%", state.energy.battery_percentage));
                batteryCapacity.setText(String.format("Capacité: %.1f Wh", state.energy.battery_capacity_wh));
                batteryVoltage.setText(String.format("Tension: %.1f V", state.energy.battery_voltage));
                
                int netPower = (int) (state.energy.power_generation - state.energy.power_consumption);
                powerGauge.setPower(netPower);
                powerConsumption.setText(String.format("Consommation: %.1f W", state.energy.power_consumption));
                powerGeneration.setText(String.format("Production: %.1f W", state.energy.power_generation));
                mppt1Power.setText(String.format("MPPT 1: %.1f W", state.mppt.solar_power_100_50));
                mppt2Power.setText(String.format("MPPT 2: %.1f W", state.mppt.solar_power_70_15));
                
                // Water Widget
                cleanTank.setWaterLevel((int) state.water.clean_tank_level);
                recycledTank1.setWaterLevel((int) state.water.recycled_tank1_level);
                recycledTank2.setWaterLevel((int) state.water.recycled_tank2_level);
                dirtyTank1.setWaterLevel((int) state.water.dirty_tank1_level);
                dirtyTank2.setWaterLevel((int) state.water.dirty_tank2_level);
                
                // Update water source and output radio groups
                int sourceId = state.water.water_source == 0 ? R.id.source_clean : R.id.source_recycled;
                waterSourceGroup.check(sourceId);
                
                int outputId = state.water.water_output == 0 ? R.id.output_dirty : R.id.output_recycled;
                waterOutputGroup.check(outputId);
                
                // Habitacle Widget
                cabinTemperature.setText(String.format("Température: %.1f°C", state.sensors.cabin_temperature));
                cabinHumidity.setText(String.format("Humidité: %.1f%%", state.sensors.humidity));
                cabinCo2.setText(String.format("CO2: %d ppm", state.sensors.co2_level));
                hoodSwitch.setChecked(state.fans.hood_fan_active);
                
                // Heater Widget
                heaterSwitch.setChecked(state.heater.heater_on);
                currentWaterTempText.setText(String.format("Eau: %.1f°C", state.heater.water_temperature));
                waterTempGauge.setTemperature(state.heater.water_temperature);
                waterTempDisplay.setText(String.format("%.1f°C", state.heater.water_temperature));
                heaterFanStatus.setText("Ventilateur: " + (state.heater.fan_active ? "Actif" : "Inactif"));
                
                // Update seekbars without triggering listeners
                waterTempSeekBar.setProgress((int) state.heater.target_water_temp - 40);
                cabinTempSeekBar.setProgress((int) state.heater.target_cabin_temp - 15);
                waterTempText.setText((int) state.heater.target_water_temp + "°C");
                cabinTempSettingText.setText((int) state.heater.target_cabin_temp + "°C");
                
                // Light Widget
                interiorLightsSwitch.setChecked(state.leds.roof.power_enabled);
                interiorBrightnessSeekBar.setProgress(state.leds.roof.brightness);
                interiorModeText.setText("Mode: " + getLedModeName(state.leds.roof.current_mode));
                
                exteriorLightsSwitch.setChecked(state.leds.exterior.power_enabled);
                exteriorBrightnessSeekBar.setProgress(state.leds.exterior.brightness);
                exteriorModeText.setText("Mode: " + getLedModeName(state.leds.exterior.current_mode));
                
                // Update color previews
                updateColorPreview(interiorColorPreview, state.leds.roof.color);
                updateColorPreview(exteriorColorPreview, state.leds.exterior.color);
            } finally {
                // Désactiver le flag après la mise à jour
                isUpdatingUI = false;
            }
        });
    }
    
    private void updateColorPreview(View colorPreview, int color) {
        colorPreview.setBackgroundColor(color);
    }
    
    private String getLedModeName(int mode) {
        switch (mode) {
            case 1: return "1 - Statique";
            case 2: return "2 - Respiration";
            case 3: return "3 - Clignotant";
            case 4: return "4 - Arc-en-ciel";
            case 5: return "5 - Scanner";
            case 6: return "6 - Vague";
            default: return mode + " - Inconnu";
        }
    }
    
    private void updateConnectionStatus() {
        runOnUiThread(() -> {
            if (serviceConnected && bleService != null) {
                if (bleService.isConnected()) {
                    bluetoothStatus.setText("Connecté");
                    bluetoothIcon.setColorFilter(ContextCompat.getColor(this, R.color.connected));
                    connectButton.setText("Déconnecter");
                } else if (bleService.isScanning()) {
                    bluetoothStatus.setText("Recherche en cours...");
                    bluetoothIcon.setColorFilter(ContextCompat.getColor(this, R.color.warning));
                    connectButton.setText("Arrêter");
                } else {
                    bluetoothStatus.setText("Déconnecté");
                    bluetoothIcon.setColorFilter(ContextCompat.getColor(this, R.color.disconnected));
                    connectButton.setText("Connecter");
                }
            } else {
                bluetoothStatus.setText("Service non disponible");
                bluetoothIcon.setColorFilter(ContextCompat.getColor(this, R.color.error));
                connectButton.setText("Connecter");
            }
        });
    }
    
    private void sendCommand(String cmd, int target, int value) {
        if (serviceConnected && bleService != null && bleService.isConnected()) {
            boolean sent = bleService.sendCommand(cmd, target, value);
            if (!sent) {
                Toast.makeText(this, "Échec d'envoi de commande", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Pas de connexion", Toast.LENGTH_SHORT).show();
        }
    }
    
    private String formatUptime(long uptimeS) {
        long seconds = uptimeS % 60;
        long minutes = (uptimeS / 60) % 60;
        long hours = (uptimeS / 3600) % 24;
        long days = uptimeS / 86400;
        
        if (days > 0) {
            return String.format("%dd %02dh%02dm", days, hours % 24, minutes % 60);
        } else if (hours > 0) {
            return String.format("%dh%02dm", hours, minutes % 60);
        } else {
            return String.format("%dm%02ds", minutes, seconds % 60);
        }
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        
        if (id == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "MainActivity onResume()");
        // Re-enregistrer le receiver au cas où il aurait été désenregistré
        if (bleReceiver != null) {
            try {
                unregisterReceiver(bleReceiver);
            } catch (IllegalArgumentException e) {
                // Le receiver n'était pas enregistré, c'est normal
                Log.d(TAG, "Receiver n'était pas enregistré lors du onResume");
            }
            
            IntentFilter filter = new IntentFilter();
            filter.addAction(VanBleService.ACTION_GATT_CONNECTED);
            filter.addAction(VanBleService.ACTION_GATT_DISCONNECTED);
            filter.addAction(VanBleService.ACTION_GATT_SERVICES_DISCOVERED);
            filter.addAction(VanBleService.ACTION_DATA_AVAILABLE);
            
            if (android.os.Build.VERSION.SDK_INT >= 34) {
                registerReceiver(bleReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(bleReceiver, filter);
            }
            Log.d(TAG, "BroadcastReceiver re-enregistré dans onResume");
        }
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "MainActivity onPause()");
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity onDestroy()");
        
        // Nettoyer le timer de reconnexion
        cancelReconnectTimer();
        
        try {
            if (serviceConnected) {
                // Nettoyer le callback avant de se déconnecter
                if (bleService != null) {
                    bleService.setCallback(null);
                }
                unbindService(serviceConnection);
            }
            
            unregisterReceiver(bleReceiver);
        } catch (Exception e) {
            Log.e(TAG, "Erreur lors du nettoyage: " + e.getMessage());
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                initializeBluetooth();
            } else {
                Toast.makeText(this, "Permissions Bluetooth requises", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                startBleService();
            } else {
                Toast.makeText(this, "Bluetooth requis pour l'application", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }
    
    // Callback methods from VanBleService.VanBleCallback interface
    @Override
    public void onConnectionStateChanged(boolean connected) {
        Log.d(TAG, "Callback onConnectionStateChanged reçu: " + connected);
        updateConnectionStatus();
        if (connected) {
            resetReconnectAttempts();
        } else {
            scheduleReconnect();
        }
    }
    
    @Override
    public void onDataReceived(String jsonData) {
        Log.d(TAG, "Callback onDataReceived reçu: " + (jsonData != null ? jsonData.length() + " caractères" : "null"));
        handleVanStateUpdate(jsonData);
    }
    
    @Override
    public void onServicesDiscovered() {
        Log.d(TAG, "Callback onServicesDiscovered reçu");
        runOnUiThread(() -> bluetoothStatus.setText("Services découverts - Prêt"));
    }
    
    // Auto-reconnection logic
    private void scheduleReconnect() {
        if (!autoReconnectEnabled || reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
            Log.d(TAG, "Reconnexion automatique désactivée ou limite atteinte");
            return;
        }
        
        reconnectAttempts++;
        Log.d(TAG, "Programmation de la reconnexion automatique (tentative " + reconnectAttempts + "/" + MAX_RECONNECT_ATTEMPTS + ")");
        
        reconnectRunnable = () -> {
            if (serviceConnected && bleService != null && !bleService.isConnected()) {
                Log.d(TAG, "Tentative de reconnexion automatique");
                bleService.startScan();
            }
        };
        
        // Utiliser le Handler du thread principal
        runOnUiThread(() -> {
            if (bluetoothStatus != null) {
                bluetoothStatus.postDelayed(reconnectRunnable, RECONNECT_DELAY_MS);
            }
        });
    }
    
    private void cancelReconnectTimer() {
        if (reconnectRunnable != null && bluetoothStatus != null) {
            bluetoothStatus.removeCallbacks(reconnectRunnable);
            reconnectRunnable = null;
        }
    }
    
    private void resetReconnectAttempts() {
        reconnectAttempts = 0;
        cancelReconnectTimer();
    }
}
