package com.van.management.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.van.management.data.VanState;

public class VanViewModel extends ViewModel {
    
    private MutableLiveData<VanState> vanState = new MutableLiveData<>();
    private MutableLiveData<Boolean> connectionState = new MutableLiveData<>();
    private MutableLiveData<String> connectionStatus = new MutableLiveData<>();
    private MutableLiveData<String> errorMessage = new MutableLiveData<>();
    
    public VanViewModel() {
        connectionState.setValue(false);
        connectionStatus.setValue("Déconnecté");
    }
    
    // Getters for LiveData
    public LiveData<VanState> getVanState() {
        return vanState;
    }
    
    public LiveData<Boolean> getConnectionState() {
        return connectionState;
    }
    
    public LiveData<String> getConnectionStatus() {
        return connectionStatus;
    }
    
    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }
    
    // Setters for updating state
    public void updateVanState(VanState state) {
        vanState.setValue(state);
    }
    
    public void updateConnectionState(boolean connected) {
        connectionState.setValue(connected);
        if (connected) {
            connectionStatus.setValue("Connecté");
            errorMessage.setValue(null);
        } else {
            connectionStatus.setValue("Déconnecté");
        }
    }
    
    public void updateConnectionStatus(String status) {
        connectionStatus.setValue(status);
    }
    
    public void updateErrorMessage(String error) {
        errorMessage.setValue(error);
    }
    
    // Utility methods
    public VanState getCurrentVanState() {
        return vanState.getValue();
    }
    
    public boolean isConnected() {
        Boolean state = connectionState.getValue();
        return state != null && state;
    }
}
