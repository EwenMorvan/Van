package com.van.management.ui.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.van.management.R;

public class PowerGaugeView extends View {
    private Paint backgroundPaint;
    private Paint chargingPaint;
    private Paint consumingPaint;
    private Paint textPaint;
    private RectF gaugeRect;
    private int power = 0; // Negative for consuming, positive for charging

    public PowerGaugeView(Context context) {
        super(context);
        init();
    }

    public PowerGaugeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public PowerGaugeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        backgroundPaint.setColor(ContextCompat.getColor(getContext(), R.color.text_secondary_light));
        backgroundPaint.setStyle(Paint.Style.STROKE);
        backgroundPaint.setStrokeWidth(8f);

        chargingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        chargingPaint.setColor(ContextCompat.getColor(getContext(), R.color.connected));
        chargingPaint.setStyle(Paint.Style.FILL);

        consumingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        consumingPaint.setColor(ContextCompat.getColor(getContext(), R.color.error));
        consumingPaint.setStyle(Paint.Style.FILL);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(ContextCompat.getColor(getContext(), R.color.text_primary_light));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(24f);

        gaugeRect = new RectF();
    }

    public void setPower(int watts) {
        this.power = watts;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        int size = Math.min(width, height);
        int centerX = width / 2;
        int centerY = height / 2;
        int radius = size / 2 - 20;

        // Draw background circle
        canvas.drawCircle(centerX, centerY, radius, backgroundPaint);

        // Draw power arc
        gaugeRect.set(centerX - radius, centerY - radius, centerX + radius, centerY + radius);
        
        if (power != 0) {
            float maxPower = 2000f; // Max 2000W
            float powerRatio = Math.abs(power) / maxPower;
            float sweepAngle = Math.min(powerRatio * 180f, 180f); // Half circle max
            
            Paint paint = power > 0 ? chargingPaint : consumingPaint;
            float startAngle = power > 0 ? -90 : 90 - sweepAngle;
            
            canvas.drawArc(gaugeRect, startAngle, sweepAngle, true, paint);
        }

        // Draw power text
        String text = Math.abs(power) + "W";
        float textY = centerY + textPaint.getTextSize() / 3;
        canvas.drawText(text, centerX, textY, textPaint);
    }
}
