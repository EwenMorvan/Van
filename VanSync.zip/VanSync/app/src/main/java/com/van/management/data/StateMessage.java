package com.van.management.data;

public class StateMessage {
    public String type;
    public long timestamp;
    public VanState data;
    
    public StateMessage() {}
}
