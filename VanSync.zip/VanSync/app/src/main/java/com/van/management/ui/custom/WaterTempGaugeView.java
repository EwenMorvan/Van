package com.van.management.ui.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.van.management.R;

public class WaterTempGaugeView extends View {
    private Paint backgroundPaint;
    private Paint tempPaint;
    private Paint textPaint;
    private RectF tempRect;
    private float temperature = 0f; // Temperature in Celsius

    public WaterTempGaugeView(Context context) {
        super(context);
        init();
    }

    public WaterTempGaugeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public WaterTempGaugeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        backgroundPaint.setColor(ContextCompat.getColor(getContext(), R.color.text_secondary_light));
        backgroundPaint.setStyle(Paint.Style.STROKE);
        backgroundPaint.setStrokeWidth(8f);

        tempPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        tempPaint.setStyle(Paint.Style.FILL);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(ContextCompat.getColor(getContext(), R.color.text_primary_light));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(28f);

        tempRect = new RectF();
    }

    public void setTemperature(float temp) {
        this.temperature = temp;
        updateTempColor();
        invalidate();
    }

    private void updateTempColor() {
        if (temperature < 30) {
            tempPaint.setColor(ContextCompat.getColor(getContext(), R.color.primary));
        } else if (temperature < 60) {
            tempPaint.setColor(ContextCompat.getColor(getContext(), R.color.warning));
        } else {
            tempPaint.setColor(ContextCompat.getColor(getContext(), R.color.error));
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        int size = Math.min(width, height);
        int centerX = width / 2;
        int centerY = height / 2;
        int radius = size / 2 - 20;

        // Draw background circle
        canvas.drawCircle(centerX, centerY, radius, backgroundPaint);

        // Draw temperature arc (0-100°C range)
        tempRect.set(centerX - radius, centerY - radius, centerX + radius, centerY + radius);
        float tempRatio = Math.min(temperature / 100f, 1f);
        float sweepAngle = tempRatio * 270f; // 3/4 circle
        canvas.drawArc(tempRect, 135, sweepAngle, true, tempPaint);

        // Draw temperature text
        String text = String.format("%.1f°C", temperature);
        float textY = centerY + textPaint.getTextSize() / 3;
        canvas.drawText(text, centerX, textY, textPaint);
    }
}
