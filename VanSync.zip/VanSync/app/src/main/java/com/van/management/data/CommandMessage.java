package com.van.management.data;

public class CommandMessage {
    public String type;
    public long timestamp;
    public String cmd;
    public int target;
    public int value;
    
    public CommandMessage() {
        this.type = "command";
        this.timestamp = System.currentTimeMillis();
    }
    
    public CommandMessage(String cmd, int target, int value) {
        this();
        this.cmd = cmd;
        this.target = target;
        this.value = value;
    }
}
