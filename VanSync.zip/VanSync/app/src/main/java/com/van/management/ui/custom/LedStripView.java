package com.van.management.ui.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.van.management.R;

import java.util.ArrayList;
import java.util.List;

public class LedStripView extends View {
    private static final int LEDS_PER_STRIP = 120;
    private static final int NUM_STRIPS = 2;
    private static final int TOTAL_LEDS = LEDS_PER_STRIP * NUM_STRIPS;

    private Paint ledPaint;
    private Paint borderPaint;
    private List<LedState> ledStates;
    private RectF ledRect;
    private float ledSize;
    private OnLedSelectionListener listener;

    public interface OnLedSelectionListener {
        void onLedSelected(int ledIndex, int color, int brightness);
        void onLedRangeSelected(int startIndex, int endIndex, int color, int brightness);
    }

    public static class LedState {
        public int color = Color.WHITE;
        public int brightness = 100; // 0-100
        public boolean isOn = false;
    }

    public LedStripView(Context context) {
        super(context);
        init();
    }

    public LedStripView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public LedStripView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        ledPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ledPaint.setStyle(Paint.Style.FILL);

        borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setColor(ContextCompat.getColor(getContext(), R.color.text_secondary_light));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1f);

        ledRect = new RectF();

        // Initialize LED states
        ledStates = new ArrayList<>();
        for (int i = 0; i < TOTAL_LEDS; i++) {
            ledStates.add(new LedState());
        }
    }

    public void setOnLedSelectionListener(OnLedSelectionListener listener) {
        this.listener = listener;
    }

    public void setLedState(int index, int color, int brightness, boolean isOn) {
        if (index >= 0 && index < TOTAL_LEDS) {
            LedState state = ledStates.get(index);
            state.color = color;
            state.brightness = brightness;
            state.isOn = isOn;
            invalidate();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        ledSize = Math.min(w / (float) LEDS_PER_STRIP, h / (float) NUM_STRIPS) - 2;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (ledSize <= 0) return;

        for (int strip = 0; strip < NUM_STRIPS; strip++) {
            for (int led = 0; led < LEDS_PER_STRIP; led++) {
                int index = strip * LEDS_PER_STRIP + led;
                LedState state = ledStates.get(index);

                float x = led * (ledSize + 2) + ledSize / 2;
                float y = strip * (ledSize + 2) + ledSize / 2;

                ledRect.set(x - ledSize / 2, y - ledSize / 2, 
                           x + ledSize / 2, y + ledSize / 2);

                // Draw LED
                if (state.isOn) {
                    int alpha = (int) (255 * (state.brightness / 100f));
                    int color = Color.argb(alpha, Color.red(state.color), 
                                         Color.green(state.color), Color.blue(state.color));
                    ledPaint.setColor(color);
                } else {
                    ledPaint.setColor(Color.GRAY);
                }

                canvas.drawOval(ledRect, ledPaint);
                canvas.drawOval(ledRect, borderPaint);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN || 
            event.getAction() == MotionEvent.ACTION_MOVE) {
            
            float x = event.getX();
            float y = event.getY();
            
            int led = (int) (x / (ledSize + 2));
            int strip = (int) (y / (ledSize + 2));
            
            if (led >= 0 && led < LEDS_PER_STRIP && strip >= 0 && strip < NUM_STRIPS) {
                int index = strip * LEDS_PER_STRIP + led;
                
                if (listener != null) {
                    LedState state = ledStates.get(index);
                    listener.onLedSelected(index, state.color, state.brightness);
                }
            }
            
            return true;
        }
        
        return super.onTouchEvent(event);
    }
}
