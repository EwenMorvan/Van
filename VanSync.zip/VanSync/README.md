# Van Management Android App

Application Android pour contrôler et surveiller le système de gestion du van via Bluetooth Low Energy (BLE).

## Structure du projet

```
app/
├── src/main/
│   ├── java/com/van/management/
│   │   ├── ui/                     # Activités Android
│   │   │   ├── MainActivity.java   # Activité principale
│   │   │   └── SettingsActivity.java # Paramètres
│   │   ├── ble/                    # Service Bluetooth
│   │   │   └── VanBleService.java  # Gestion BLE
│   │   ├── data/                   # Modèles de données
│   │   │   ├── VanState.java       # État du van
│   │   │   ├── StateMessage.java   # Message d'état
│   │   │   ├── CommandMessage.java # Message de commande
│   │   │   └── ResponseMessage.java # Message de réponse
│   │   ├── viewmodel/              # Architecture MVVM
│   │   │   └── VanViewModel.java   # ViewModel principal
│   │   └── utils/                  # Utilitaires
│   │       ├── ErrorCodes.java     # Codes d'erreur
│   │       └── PreferencesManager.java # Gestion préférences
│   ├── res/
│   │   ├── layout/                 # Interfaces utilisateur
│   │   │   ├── activity_main.xml   # Interface principale
│   │   │   └── activity_settings.xml # Interface paramètres
│   │   ├── values/                 # Ressources
│   │   │   ├── strings.xml         # Textes
│   │   │   ├── colors.xml          # Couleurs
│   │   │   └── styles.xml          # Styles
│   │   ├── drawable/               # Icônes et graphiques
│   │   └── menu/                   # Menus
│   └── AndroidManifest.xml         # Configuration app
├── build.gradle                    # Configuration build
└── proguard-rules.pro              # Règles obfuscation
```

## Fonctionnalités

### Interface principale
- **État de connexion** : Statut BLE et contrôles de connexion
- **Informations système** : Temps de fonctionnement, erreurs
- **Capteurs** : Carburant, température, humidité, CO2
- **Chauffage** : Contrôle marche/arrêt, températures cibles
- **Panneaux solaires** : État des contrôleurs MPPT
- **Éclairage** : Contrôle LEDs plafond et extérieur
- **Ventilation** : Contrôle vitesse ventilateurs

### Communication BLE
- **Connexion automatique** : Recherche et connexion au van
- **Notifications temps réel** : Réception état du van
- **Envoi commandes** : Contrôle des systèmes
- **Gestion reconnexion** : Reconnexion automatique en cas de déconnexion

### Paramètres
- **Connexion automatique** : Activation/désactivation
- **Écran toujours allumé** : Pour utilisation continue
- **Thème sombre** : Interface sombre
- **Intervalle notifications** : Fréquence mise à jour (100ms-5s)

## Installation dans Android Studio

1. **Copier les fichiers** :
   ```bash
   # Copier tous les fichiers .java vers src/main/java/
   # Copier tous les fichiers .xml vers src/main/res/
   # Copier build.gradle, AndroidManifest.xml, etc.
   ```

2. **Synchroniser le projet** :
   - Ouvrir Android Studio
   - File → Open → Sélectionner le dossier du projet
   - Sync Now quand demandé

3. **Vérifier les dépendances** :
   - Gradle va télécharger automatiquement les dépendances
   - Vérifier que toutes les bibliothèques sont bien résolues

## Configuration requise

### Permissions Android
- `BLUETOOTH` - Communication Bluetooth de base
- `BLUETOOTH_ADMIN` - Administration Bluetooth
- `BLUETOOTH_CONNECT` - Connexion BLE (Android 12+)
- `BLUETOOTH_SCAN` - Scan BLE (Android 12+)
- `ACCESS_FINE_LOCATION` - Requis pour scan BLE

### Versions Android
- **Min SDK** : 21 (Android 5.0)
- **Target SDK** : 34 (Android 14)
- **Compile SDK** : 34

### Dépendances principales
- `androidx.appcompat` - Compatibilité
- `com.google.android.material` - Material Design
- `com.google.code.gson` - Parser JSON
- `androidx.lifecycle` - Architecture MVVM

## Utilisation

### Première connexion
1. Activer Bluetooth sur la tablette
2. Lancer l'application
3. Accorder les permissions demandées
4. L'app recherche automatiquement le van
5. Connexion automatique quand trouvé

### Contrôle du chauffage
- **Switch** : Marche/arrêt du chauffage
- **Slider eau** : Température cible eau (40-90°C)
- **Slider cabine** : Température cible cabine (10-30°C)

### Contrôle éclairage
- **Slider plafond** : Luminosité LEDs intérieures
- **Switch extérieur** : Activation LEDs extérieures
- **Slider extérieur** : Luminosité LEDs extérieures

### Contrôle ventilation
- **Slider boîtier** : Vitesse ventilateur électronique
- **Slider chauffage** : Vitesse ventilateur chauffage
- **Switch hotte** : Activation/désactivation hotte

## Protocole de communication

Voir le fichier `COMMUNICATION_PROTOCOL.md` pour les détails complets du protocole BLE.

### UUIDs BLE
- **Service** : `0000AAA0-0000-1000-8000-00805F9B34FB`
- **Commandes** : `0000AAA1-0000-1000-8000-00805F9B34FB` (Write)
- **États** : `0000AAA2-0000-1000-8000-00805F9B34FB` (Notify)

### Format des messages
- **Encodage** : JSON UTF-8
- **Taille max** : 2048 bytes
- **MTU BLE** : 256-512 bytes (négocié)

## Développement

### Architecture
- **Pattern MVVM** : Séparation vue/logique
- **LiveData** : Observation réactive des données
- **Service BLE** : Gestion connexion en arrière-plan
- **SharedPreferences** : Sauvegarde paramètres

### Tests
- Tester sur vrai dispositif (émulateur ne supporte pas BLE)
- Vérifier permissions sur Android 12+
- Tester reconnexion après perte de signal
- Vérifier performance avec notifications rapides

### Améliorations possibles
- Historique des données
- Graphiques temps réel
- Alarmes et notifications
- Mode hors ligne
- Sauvegarde configuration

## Dépannage

### Problèmes de connexion
- Vérifier que Bluetooth est activé
- S'assurer que le van est à portée
- Redémarrer Bluetooth si nécessaire
- Vérifier permissions location

### Problèmes de performance
- Réduire intervalle notifications si lag
- Vérifier MTU négocié
- Surveiller utilisation CPU/mémoire

### Logs de debug
Activer les logs dans Android Studio pour voir les événements BLE détaillés.

## Contact

Pour questions techniques ou problèmes, consulter les logs ESP32 et Android pour diagnostic.
